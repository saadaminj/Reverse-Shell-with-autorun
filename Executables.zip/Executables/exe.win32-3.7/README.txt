Client is for same pc, you have to explicity run it, it will run on background. to quit it. you have to open server.exe and enter command "quit". both will quit. if you enter "client quit", only client side will exit.

Client2 is for devices connected to same router, but the IP given is static and for the PC of Group leader, so it might not work for others.

Server.exe has button "bind socket" which is in black color at the top left corner, whenever you want to search for clients, click on that button it will search for 2 seconds. if found the color of the label will turn green. if you think that client might disconnected, so click on bind socket button again. if it still appears green so the client is connected, if it turn red, the client is disconnected.